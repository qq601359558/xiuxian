"""
天道导演 M1：AI 提案世界级走向，规则门禁落账。

原则：
  - AI 决定「世界发生什么类型的事」
  - 数值/胜负/掉落仍由规则权威；提案 effects 过白名单
  - 无 AI 不伪造「天道已裁」
"""
from __future__ import annotations

import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from config import (
    DIRECTOR_GOAL_FANOUT,
    DIRECTOR_MAX_ACTIVE,
    DIRECTOR_MIN_INTERVAL_SECONDS,
    DIRECTOR_STRIP_EFFECT_KEYS,
    DIRECTOR_TICK_INTERVAL_SECONDS,
    DIRECTOR_TTL_SECONDS,
    DIRECTOR_TYPES,
    SECRET_REALMS,
    SEASON_WARN_DAYS,
    WORLD_LOCATIONS,
    local_ai_allowed,
)
from storage.db import CharacterRepository, WorldStateRepository
from core.models import CharacterStatus
from core.season import season_info
from core.world_channel import WorldChannel
from ai.audit import write_audit
from ai.gateway import ai_block_reason, ai_ready

_KEY = "director"


def _now(now: Optional[float] = None) -> float:
    return now if now is not None else time.time()


def _load() -> Dict[str, Any]:
    try:
        data = WorldStateRepository.get(_KEY) or {}
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    data.setdefault("last_run_ts", 0.0)
    data.setdefault("last_trigger", "")
    data.setdefault("last_source", "")
    data.setdefault("last_error", "")
    data.setdefault("last_accepted", 0)
    data.setdefault("active", [])
    data.setdefault("history", [])
    data.setdefault("player_events", [])
    data.setdefault("stats", {"runs": 0, "accepted": 0, "rejected": 0, "attempts": 0})
    if not isinstance(data.get("stats"), dict):
        data["stats"] = {"runs": 0, "accepted": 0, "rejected": 0, "attempts": 0}
    data["stats"].setdefault("attempts", 0)
    return data


def _save(state: Dict[str, Any]) -> None:
    try:
        WorldStateRepository.set(_KEY, state)
    except Exception:
        pass


def _audit(rec: Dict[str, Any]) -> None:
    try:
        write_audit({"source": "ai.world_director", **rec})
    except Exception:
        pass


def _prune_active(state: Dict[str, Any], now: float) -> None:
    active = []
    expired = []
    for d in state.get("active") or []:
        if not isinstance(d, dict):
            continue
        if float(d.get("expires_at") or 0) >= now:
            active.append(d)
        else:
            expired.append(d)
    if expired:
        for d in expired:
            _push_history(
                state,
                f"{int(now)}|{d.get('type')}|{d.get('title')}|expired|{d.get('id')}",
            )
            # 大事记：导演态势消散，供后续世情/传说引用
            try:
                from storage.db import ChronicleRepository

                ChronicleRepository.record(
                    "天道",
                    "导演",
                    f"【{d.get('title')}】态势渐散（{d.get('type')}）。",
                )
            except Exception:
                pass
        state["active"] = active
        # 读路径 prune 也要落库，否则 history/active 丢失
        try:
            WorldStateRepository.set(_KEY, state)
        except Exception:
            pass
    else:
        state["active"] = active


def _push_history(state: Dict[str, Any], line: str, limit: int = 20) -> None:
    hist = list(state.get("history") or [])
    hist.append(line[:120])
    state["history"] = hist[-limit:]


def gather_world_brief(now: Optional[float] = None) -> Dict[str, Any]:
    """导演事实简报（给 AI / 本地降级共用）"""
    t = _now(now)
    alive_players: List[str] = []
    alive_npcs: List[str] = []
    blood: List[str] = []
    realm_hist: Dict[str, int] = {}
    try:
        for c in CharacterRepository.list_all_alive():
            if c.status == CharacterStatus.DEAD:
                continue
            uid = str(getattr(c, "user_id", "") or "")
            realm_hist[c.realm.name] = realm_hist.get(c.realm.name, 0) + 1
            if c.karma.is_blood_marked() or c.karma.sin_value >= 100:
                blood.append(f"{c.name}({c.realm.name}@{c.location}业力{c.karma.sin_value})")
            if uid.startswith("npc_") or uid.startswith("ai_npc_"):
                alive_npcs.append(c.name)
            else:
                alive_players.append(c.name)
    except Exception:
        pass
    realms = []
    try:
        from core.secret_realm import realm_status

        for r in realm_status(t):
            realms.append(
                f"{r.get('name')}@{r.get('location')} {'开启' if r.get('is_open') else '未开'}"
            )
    except Exception:
        realms = [f"{rid}" for rid in list(SECRET_REALMS.keys())[:6]]
    rumors: List[str] = []
    try:
        from core import rumors as rum

        for r in rum.list_rumors(limit=5) if hasattr(rum, "list_rumors") else []:
            text = r.get("text") if isinstance(r, dict) else str(r)
            if text:
                rumors.append(str(text)[:60])
    except Exception:
        rumors = []
    if not rumors:
        try:
            majors = [
                m.text
                for m in WorldChannel.recent(limit=8)
                if getattr(m, "level", "") in ("major", "epic", "gm")
            ][-4:]
            rumors = majors
        except Exception:
            rumors = []
    arcs_line = "无"
    legends_line = "无"
    try:
        from core.world_arc import active_arcs

        _arcs = active_arcs(t)[:4]
        if _arcs:
            arcs_line = "；".join(
                f"{a.get('stage')}:{a.get('kind')}:{a.get('title')}@{a.get('location') or '—'}"
                for a in _arcs
            )
    except Exception:
        pass
    try:
        from core.legends import list_legends

        _legs = list_legends(limit=4)
        if _legs:
            legends_line = "；".join(x.text[:40] for x in _legs)
    except Exception:
        pass
    mods_line = ""
    try:
        mods = world_modifiers(t)
        mods_line = (
            f"当前修饰：血煞地={mods.get('blood_tide_locations') or '无'} "
            f"宗门紧张={mods.get('sect_tensions') or '无'} "
            f"大劫={'是' if mods.get('calamity_forecast') else '否'}"
        )
    except Exception:
        mods_line = ""
    bias_line = "无"
    try:
        from core.era_reentry import active_bias, preferred_directive_types, TYPE_CN

        bias = active_bias(t)
        if bias:
            pref = preferred_directive_types(t, top=3)
            bias_line = "；".join(
                f"{TYPE_CN.get(k, k)}({bias.get(k, 0):.1f})" for k in pref
            )
    except Exception:
        bias_line = "无"
    info = season_info(t)
    locs = list(WORLD_LOCATIONS.keys())
    brief_text = (
        f"存活玩家{len(alive_players)}人：{'、'.join(alive_players[:8]) or '无'}；"
        f"NPC{len(alive_npcs)}人。\n"
        f"境界分布：{realm_hist or '—'}\n"
        f"血煞/重业：{'；'.join(blood[:6]) or '无'}\n"
        f"秘境：{'；'.join(realms[:6]) or '—'}\n"
        f"近闻：{'；'.join(rumors) or '风平浪静'}\n"
        f"进行中世界弧：{arcs_line}\n"
        f"近传说：{legends_line}\n"
        f"纪元回流权重（可优先提案）：{bias_line}\n"
        f"{mods_line}\n"
        f"地点库：{'、'.join(locs[:10])}\n"
        f"秘境库：{'、'.join(list(SECRET_REALMS.keys()))}\n"
        f"纪元第 {info.get('season_number')} 天；剩余约 {info.get('remain_real_days')} 天；"
        f"大劫窗口={'是' if info.get('is_final_week') else '否'}\n"
        f"注意：勿与「进行中世界弧/当前修饰」重复提案同质指令；"
        f"史笔余势类型应优先考虑。"
    )
    return {
        "text": brief_text,
        "players": alive_players,
        "npcs": alive_npcs,
        "blood": blood,
        "realms": realms,
        "rumors": rumors,
        "arcs_line": arcs_line,
        "legends_line": legends_line,
        "era_bias": bias_line,
        "season": info,
        "locations": locs,
        "secret_realms": list(SECRET_REALMS.keys()),
    }


def _strip_effects(raw: Any) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    out: Dict[str, Any] = {}
    for k, v in raw.items():
        key = str(k)
        if key in DIRECTOR_STRIP_EFFECT_KEYS:
            continue
        if key in (
            "goal_title",
            "goal_detail",
            "whisper",
            "realm_id",
            "location",
            "sect_a",
            "sect_b",
            "sect",
            "order_kind",
            "kind",
            "target_sect",
            "target_name",
        ):
            out[key] = str(v)[:80] if v is not None else ""
        elif key == "force_open":
            out[key] = bool(v)
        else:
            # 未知键：剥离（宁少勿滥）
            continue
    return out


def admit_directive(
    raw: Any,
    *,
    season: Optional[Dict[str, Any]] = None,
    now: Optional[float] = None,
) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """规则门禁：返回 (ok, reason, cleaned|None)"""
    if not isinstance(raw, dict):
        return False, "not_object", None
    dtype = str(raw.get("type") or "").strip().lower()
    if dtype not in DIRECTOR_TYPES:
        return False, f"illegal_type:{dtype}", None
    if dtype == "calamity_forecast":
        info = season if season is not None else season_info(_now(now))
        in_window = bool(info.get("is_final_week")) or float(
            info.get("remain_real_days") or 0
        ) <= float(SEASON_WARN_DAYS)
        if not in_window:
            return False, "calamity_out_of_window", None
    title = str(raw.get("title") or "").strip()[:40] or "天道有感"
    narrative = str(raw.get("narrative") or "").strip()[:160]
    if not narrative:
        return False, "empty_narrative", None
    location = str(raw.get("location") or "").strip()[:40]
    if location and location not in WORLD_LOCATIONS and location not in SECRET_REALMS:
        location = ""
    effects = _strip_effects(raw.get("effects"))
    if dtype == "secret_realm_pressure":
        rid = str(effects.get("realm_id") or raw.get("realm_id") or "").strip()
        if not rid:
            # 尝试从 narrative/location 模糊匹配简报秘境
            for name in SECRET_REALMS:
                if name in narrative or name in location:
                    rid = name
                    break
        if rid not in SECRET_REALMS:
            return False, "unknown_realm", None
        effects["realm_id"] = rid
        if location not in WORLD_LOCATIONS:
            location = str(SECRET_REALMS.get(rid, {}).get("location") or location or "")
    if dtype == "sect_tension":
        sa = str(effects.get("sect_a") or "").strip()[:20]
        sb = str(effects.get("sect_b") or "").strip()[:20]
        if not sa or not sb:
            return False, "sect_pair_required", None
        effects["sect_a"] = sa
        effects["sect_b"] = sb
    if dtype == "blood_tide":
        loc = str(effects.get("location") or location or "").strip()
        if loc and loc not in WORLD_LOCATIONS:
            loc = ""
        effects["location"] = loc
        location = loc or location
    if dtype == "faction_order":
        sect = str(effects.get("sect") or "").strip()
        from config import SECTS_CONFIG as _SC

        if sect not in _SC:
            return False, "unknown_sect", None
        effects["sect"] = sect
        ok_kind = str(effects.get("order_kind") or effects.get("kind") or "patrol").strip()
        if ok_kind not in ("patrol", "hunt", "boycott", "siege"):
            ok_kind = "patrol"
        effects["order_kind"] = ok_kind
        ts = str(effects.get("target_sect") or "").strip()
        if ts and ts not in _SC:
            effects["target_sect"] = ""
        tn = str(effects.get("target_name") or "").strip()[:20]
        effects["target_name"] = tn
    if dtype == "sect_siege":
        sect = str(effects.get("sect") or "").strip()
        from config import SECTS_CONFIG as _SC

        if sect not in _SC:
            return False, "unknown_sect", None
        effects["sect"] = sect
        tn = str(effects.get("target_name") or "").strip()[:20]
        if not tn:
            return False, "siege_target_required", None
        effects["target_name"] = tn
    try:
        priority = int(raw.get("priority") or 1)
    except (TypeError, ValueError):
        priority = 1
    duration = raw.get("duration_sec")
    try:
        duration = float(duration) if duration is not None else DIRECTOR_TTL_SECONDS
    except (TypeError, ValueError):
        duration = DIRECTOR_TTL_SECONDS
    duration = max(300.0, min(float(DIRECTOR_TTL_SECONDS) * 3, float(duration)))
    t = _now(now)
    level = "epic" if dtype == "calamity_forecast" else "major"
    cleaned = {
        "id": f"d_{uuid.uuid4().hex[:8]}",
        "type": dtype,
        "title": title,
        "narrative": narrative,
        "location": location,
        "priority": max(1, min(5, priority)),
        "duration_sec": duration,
        "effects": effects,
        "created_at": t,
        "expires_at": t + duration,
        "channel_level": level,
        "applied": {},
    }
    return True, "", cleaned


def _is_duplicate_directive(cleaned: Dict[str, Any], now: Optional[float] = None) -> bool:
    """活跃指令同 type（+location/realm）视为重复，驳回防刷屏"""
    t = _now(now)
    state = _load()
    _prune_active(state, t)
    dtype = cleaned.get("type")
    loc = cleaned.get("location") or ""
    rid = str((cleaned.get("effects") or {}).get("realm_id") or "")
    sa = str((cleaned.get("effects") or {}).get("sect_a") or "")
    for d in state.get("active") or []:
        if d.get("type") != dtype:
            continue
        if dtype == "secret_realm_pressure":
            if rid and (d.get("effects") or {}).get("realm_id") == rid:
                return True
            continue
        if dtype == "sect_tension":
            da = str((d.get("effects") or {}).get("sect_a") or "")
            db = str((d.get("effects") or {}).get("sect_b") or "")
            if sa and {da, db} == {
                sa,
                str((cleaned.get("effects") or {}).get("sect_b") or ""),
            }:
                return True
            continue
        if dtype == "calamity_forecast":
            return True
        # blood_tide / omen：同地点或全局
        if (d.get("location") or "") == loc:
            return True
        if not loc and not d.get("location"):
            return True
    return False


def _dedupe_cleaned(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """同批提案内去重"""
    out: List[Dict[str, Any]] = []
    seen = set()
    for d in rows:
        key = (
            d.get("type"),
            d.get("location") or "",
            str((d.get("effects") or {}).get("realm_id") or ""),
            str((d.get("effects") or {}).get("sect_a") or ""),
            str((d.get("effects") or {}).get("sect_b") or ""),
        )
        if key in seen:
            continue
        seen.add(key)
        out.append(d)
    return out


def _local_directives(brief: Dict[str, Any], now: float) -> List[Dict[str, Any]]:
    """无真 AI 时的确定性降级（source=local，不冒充天道裁决）"""
    info = brief.get("season") or {}
    raw_list: List[Dict[str, Any]] = []
    # M5：史笔余势优先注入
    try:
        from core.era_reentry import seed_local_directives

        raw_list.extend(seed_local_directives(now=now) or [])
    except Exception:
        pass
    open_realms = [r for r in (brief.get("realms") or []) if "开启" in str(r)]
    if open_realms:
        rid = ""
        for name in SECRET_REALMS:
            if any(name in str(x) for x in open_realms):
                rid = name
                break
        if rid:
            raw_list.append(
                {
                    "type": "secret_realm_pressure",
                    "title": "禁制松动",
                    "narrative": f"天象示警：【{rid}】禁制波动，附近灵气紊乱，或有机缘亦有杀劫。",
                    "location": SECRET_REALMS[rid].get("location", ""),
                    "effects": {"realm_id": rid, "force_open": False},
                    "priority": 2,
                }
            )
    if brief.get("blood"):
        loc_b = ""
        try:
            loc_b = (str(brief.get("blood")[0]).split("@")[-1].split("业力")[0]) if brief.get("blood") else ""
        except Exception:
            loc_b = ""
        if loc_b not in WORLD_LOCATIONS:
            loc_b = ""
        raw_list.append(
            {
                "type": "blood_tide",
                "title": "血煞微涨",
                "narrative": "坊间血气浮动，除凶与避祸之议再起，安全区外宜谨慎。",
                "location": loc_b,
                "effects": {"location": loc_b, "whisper": "血煞异动"},
                "priority": 2,
            }
        )
    if info.get("is_final_week") or float(info.get("remain_real_days") or 0) <= SEASON_WARN_DAYS:
        raw_list.append(
            {
                "type": "calamity_forecast",
                "title": "大劫将至",
                "narrative": "天道示警：纪元终局临近，未安顿道统者宜早做决断。",
                "location": "",
                "effects": {"whisper": "大劫预兆"},
                "priority": 3,
            }
        )
    # 宗门紧张（有 NPC 时才给一对）
    try:
        sects = []
        for c in CharacterRepository.list_all_alive():
            uid = str(getattr(c, "user_id", "") or "")
            if not (uid.startswith("npc_") or uid.startswith("ai_npc_")):
                continue
            if c.sect and c.sect not in sects:
                sects.append(c.sect)
            if len(sects) >= 2:
                break
        if len(sects) >= 2:
            raw_list.append(
                {
                    "type": "sect_tension",
                    "title": "两宗龃龉",
                    "narrative": f"【{sects[0]}】与【{sects[1]}】门下近日互有龃龉，坊间议论纷纷。",
                    "effects": {"sect_a": sects[0], "sect_b": sects[1], "whisper": "紧张"},
                    "priority": 2,
                }
            )
    except Exception:
        pass
    if not raw_list:
        raw_list.append(
            {
                "type": "omen",
                "title": "灵机一现",
                "narrative": "山雨欲来风满楼，世间看似平静，暗流已在宗门与坊市之间游走。",
                "location": "青云坊市客栈",
                "effects": {
                    "goal_title": "静观天道",
                    "goal_detail": "近日宜多看 /世情 /天道，留意机缘与风声。",
                    "whisper": "风起",
                },
                "priority": 1,
            }
        )
    cleaned: List[Dict[str, Any]] = []
    for raw in raw_list[:DIRECTOR_MAX_ACTIVE]:
        ok, _reason, item = admit_directive(raw, season=info, now=now)
        if ok and item:
            item["source"] = "local"
            cleaned.append(item)
    cleaned = _dedupe_cleaned(cleaned)
    out = []
    for item in cleaned:
        if _is_duplicate_directive(item, now=now):
            continue
        out.append(item)
    return out[:DIRECTOR_MAX_ACTIVE]


def _ai_propose(
    brief: Dict[str, Any],
    *,
    force: bool,
    now: float,
) -> Tuple[List[Dict[str, Any]], str, str]:
    """返回 (directives, source, error)"""
    # 测试/降级：local_ai_allowed 且未配置通道 → 本地；配置了通道则优先真 AI
    from config import ai_available

    use_local_first = local_ai_allowed() and not ai_available()
    if use_local_first:
        return _local_directives(brief, now), "local", ""
    if not ai_ready():
        if local_ai_allowed():
            return _local_directives(brief, now), "local", ""
        return [], "error", ai_block_reason() or "AI 通道未配置"
    season = brief.get("season") or {}
    try:
        from ai.router import invoke

        payload = {
            "world_brief": brief.get("text", ""),
            "season_remain_days": float(season.get("remain_real_days") or 0),
            "force": bool(force),
            # 深化：结构化事实，降低幻觉
            "structured": {
                "players": brief.get("players") or [],
                "blood": brief.get("blood") or [],
                "realms": brief.get("realms") or [],
                "locations": (brief.get("locations") or [])[:12],
                "secret_realms": brief.get("secret_realms") or [],
                "arcs_line": brief.get("arcs_line") or "",
                "legends_line": brief.get("legends_line") or "",
                "era_bias": brief.get("era_bias") or "",
                "calamity_window": bool(season.get("is_final_week"))
                or float(season.get("remain_real_days") or 0) <= SEASON_WARN_DAYS,
            },
        }
        r = invoke(
            "world_director",
            payload=payload,
            actor_id="world_director",
            timeout=25.0,
        )
        if not r.get("ok"):
            err = str(r.get("error") or "ai_failed")
            if local_ai_allowed():
                return _local_directives(brief, now), "local", err
            return [], "error", err
        data = r.get("data") or {}
        raw_list = data.get("directives") if isinstance(data, dict) else None
        if raw_list is None and isinstance(data, list):
            raw_list = data
        if not isinstance(raw_list, list):
            raw_list = []
        # 深化：结构化 brief 一并给模型（router payload 已带；此处保底）
        cleaned = []
        rejected = 0
        for raw in raw_list[:DIRECTOR_MAX_ACTIVE * 2]:
            ok, reason, item = admit_directive(raw, season=season, now=now)
            if ok and item:
                item["source"] = "ai"
                cleaned.append(item)
            else:
                rejected += 1
                _audit(
                    {
                        "event": "reject",
                        "reason": reason,
                        "raw_type": str((raw or {}).get("type") if isinstance(raw, dict) else raw),
                        "source": "ai",
                    }
                )
        try:
            from core.era_reentry import reorder_by_bias

            cleaned = reorder_by_bias(cleaned, now=now)
        except Exception:
            pass
        cleaned = _dedupe_cleaned(cleaned)
        final = []
        for item in cleaned:
            if _is_duplicate_directive(item, now=now):
                rejected += 1
                _audit({"event": "reject", "reason": "duplicate_active", "source": "ai", "type": item.get("type")})
                continue
            final.append(item)
            if len(final) >= DIRECTOR_MAX_ACTIVE:
                break
        # M5/M-多样性：AI 全 omen 或缺世界态势类型时，从世界态势补种
        if final:
            try:
                from core.era_reentry import (
                    preferred_directive_types,
                    seed_local_directives,
                    note_citation,
                    variety_seeds_from_world,
                )

                have = {x.get("type") for x in final}
                pref = preferred_directive_types(now=now, top=2)
                # 1) 史笔缺类型
                if pref and not any(p in have for p in pref):
                    for seed in seed_local_directives(now=now):
                        if seed.get("type") not in pref:
                            continue
                        ok_s, _rs, item_s = admit_directive(seed, season=season, now=now)
                        if ok_s and item_s and not _is_duplicate_directive(item_s, now=now):
                            item_s["source"] = "ai+era"
                            final.append(item_s)
                            note_citation("director_supplement_era")
                            have.add(item_s.get("type"))
                            break
                # 2) 世界态势多样性：全 omen 或缺血煞/宗门/秘境时补
                need_variety = have == {"omen"} or not (
                    have & {"blood_tide", "sect_tension", "secret_realm_pressure", "faction_order", "sect_siege"}
                )
                if need_variety:
                    for seed in variety_seeds_from_world(now=now):
                        if seed.get("type") in have:
                            continue
                        ok_s, _rs, item_s = admit_directive(seed, season=season, now=now)
                        if ok_s and item_s and not _is_duplicate_directive(item_s, now=now):
                            item_s["source"] = "ai+world"
                            final.append(item_s)
                            have.add(item_s.get("type"))
                            note_citation("director_supplement_world")
                            if len(final) >= DIRECTOR_MAX_ACTIVE:
                                break
                        if len(final) >= DIRECTOR_MAX_ACTIVE:
                            break
            except Exception:
                pass
        if rejected:
            try:
                st = _load()
                st["stats"]["rejected"] = int(st["stats"].get("rejected") or 0) + rejected
                _save(st)
            except Exception:
                pass
        return final, "ai", (f"rejected={rejected}" if rejected and not final else "")
    except Exception as e:
        err = f"{type(e).__name__}: {e}"[:200]
        if local_ai_allowed():
            return _local_directives(brief, now), "local", err
        return [], "error", err


def active_directives(now: Optional[float] = None) -> List[Dict[str, Any]]:
    """仍存活的导演指令（供 NPC/江湖/战斗等系统读取）"""
    t = _now(now)
    state = _load()
    _prune_active(state, t)
    out = []
    for d in state.get("active") or []:
        if isinstance(d, dict) and float(d.get("expires_at") or 0) >= t:
            out.append(d)
    return out


def world_modifiers(now: Optional[float] = None) -> Dict[str, Any]:
    """
    由活跃指令 + 世界弧推导的世界修饰（规则侧消费，AI 不直接改数）。
    """
    t = _now(now)
    active = active_directives(t)
    blood_locs: List[str] = []
    sects: List[Tuple[str, str]] = []
    realms: List[str] = []
    calamity = False
    for d in active:
        dtype = d.get("type")
        eff = d.get("effects") or {}
        loc = str(eff.get("location") or d.get("location") or "").strip()
        if dtype == "blood_tide":
            if loc:
                blood_locs.append(loc)
        elif dtype == "sect_tension":
            sa = str(eff.get("sect_a") or "").strip()
            sb = str(eff.get("sect_b") or "").strip()
            if sa and sb:
                sects.append((sa, sb))
        elif dtype == "secret_realm_pressure":
            rid = str(eff.get("realm_id") or "").strip()
            if rid:
                realms.append(rid)
        elif dtype == "calamity_forecast":
            calamity = True
    hunt_heat = 1.35 if blood_locs else (1.15 if any(d.get("type") == "blood_tide" for d in active) else 1.0)
    # 叠加 M2 世界弧 + M3 势力
    try:
        from core.world_arc import arc_modifiers

        am = arc_modifiers(t)
        for loc in am.get("blood_tide_locations") or []:
            if loc not in blood_locs:
                blood_locs.append(loc)
        for pair in am.get("sect_tensions") or []:
            if pair not in sects:
                sects.append(pair)
        for rid in am.get("realm_pressure_ids") or []:
            if rid not in realms:
                realms.append(rid)
        calamity = calamity or bool(am.get("calamity_forecast"))
        hunt_heat = max(hunt_heat, float(am.get("hunt_heat") or 1.0))
        heat_by_location = dict(am.get("heat_by_location") or {})
    except Exception:
        heat_by_location = {}
    faction_info: Dict[str, Any] = {}
    try:
        from core.faction import faction_modifiers

        fm = faction_modifiers(t)
        faction_info = fm
        for pair in fm.get("hostile_pairs") or []:
            if pair not in sects:
                sects.append(pair)
        for s in fm.get("active_sieges") or []:
            loc_s = s.get("loc") or ""
            if loc_s:
                heat_by_location[loc_s] = max(heat_by_location.get(loc_s, 1.0), 1.35)
        if fm.get("active_sieges"):
            hunt_heat = max(hunt_heat, 1.25)
    except Exception:
        pass
    echo_info: Dict[str, Any] = {}
    try:
        from core.player_echo import echo_modifiers

        em = echo_modifiers(t)
        echo_info = em
        for loc, heat in (em.get("heat_by_location") or {}).items():
            heat_by_location[loc] = max(heat_by_location.get(loc, 1.0), float(heat))
        hunt_heat = max(hunt_heat, float(em.get("hunt_heat") or 1.0))
    except Exception:
        pass
    for loc in blood_locs:
        heat_by_location[loc] = max(heat_by_location.get(loc, 1.0), 1.45)
    return {
        "blood_tide_locations": blood_locs,
        "sect_tensions": sects,
        "realm_pressure_ids": realms,
        "calamity_forecast": calamity,
        "hunt_heat": hunt_heat,
        "heat_by_location": heat_by_location,
        "faction": faction_info,
        "echo": echo_info,
        "active_types": [d.get("type") for d in active],
        "n_active": len(active),
    }


def location_heat(location: str, now: Optional[float] = None) -> float:
    """某地点因导演/世界弧/势力态势产生的行动热度（1.0=常态）"""
    if not location:
        return 1.0
    mods = world_modifiers(now)
    by = mods.get("heat_by_location") or {}
    heat = 1.0
    if location in by:
        heat = float(by[location])
    elif location in (mods.get("blood_tide_locations") or []):
        heat = 1.45
    elif mods.get("calamity_forecast"):
        heat = 1.15
    return heat


def location_heat_for(location: str, viewer_sect: str = "", now: Optional[float] = None) -> float:
    """带宗门/玩家回写视角的地点热度"""
    heat = location_heat(location, now)
    try:
        from core.faction import location_faction_heat

        heat = max(heat, location_faction_heat(location, viewer_sect, now))
    except Exception:
        pass
    try:
        from core.player_echo import region_heat

        heat = max(heat, region_heat(location, now))
    except Exception:
        pass
    return heat


def agenda_bias_for_npc(npc: Any, now: Optional[float] = None) -> Optional[Dict[str, str]]:
    """
    导师态势 + 世界弧 + 势力 + 玩家回写 对 NPC 议程的规则偏置。
    """
    if npc is None:
        return None
    try:
        from core.player_echo import agenda_bias_from_echo

        eb = agenda_bias_from_echo(npc, now=now)
        if eb:
            return eb
    except Exception:
        pass
    try:
        from core.faction import agenda_bias_for_npc as faction_bias

        fb = faction_bias(npc, now=now)
        if fb:
            return fb
    except Exception:
        pass
    try:
        from core.world_arc import agenda_bias_from_arcs

        ab = agenda_bias_from_arcs(npc, now=now)
        if ab:
            return ab
    except Exception:
        pass
    mods = world_modifiers(now)
    loc = getattr(npc, "location", "") or ""
    sect = getattr(npc, "sect", "") or ""
    if loc and loc in mods.get("blood_tide_locations"):
        return {
            "agenda_type": "patrol",
            "note": "天道导演·血煞潮：同场戒备，加强巡守",
        }
    for sa, sb in mods.get("sect_tensions") or []:
        if sect and sect in (sa, sb):
            if getattr(npc, "karma", None) is not None and npc.karma.sin_value >= 80:
                return {
                    "agenda_type": "revenge",
                    "note": f"天道导演·宗门紧张（{sa}×{sb}）：借势寻隙",
                }
            return {
                "agenda_type": "patrol",
                "note": f"天道导演·宗门紧张（{sa}×{sb}）：谨守门户",
            }
    if mods.get("calamity_forecast"):
        try:
            if npc.realm and getattr(npc.realm, "is_full", False):
                return {"agenda_type": "seclusion", "note": "天道导演·大劫预兆：闭关冲关"}
        except Exception:
            pass
        return {"agenda_type": "survive", "note": "天道导演·大劫预兆：趋吉避凶"}
    return None


def note_player_event(
    kind: str,
    *,
    character: Any = None,
    location: str = "",
    detail: str = "",
    force_run: bool = False,
    now: Optional[float] = None,
) -> Dict[str, Any]:
    """
    玩家/世界重大行为惊动天道：写入导演近事，必要时触发一轮提案。
    kind: kill | blood_mark | sin_spike | breakthrough | manual
    """
    t = _now(now)
    state = _load()
    events = list(state.get("player_events") or [])
    name = getattr(character, "name", "") or ""
    sin = 0
    marked = False
    try:
        if character is not None:
            sin = int(character.karma.sin_value)
            marked = bool(character.karma.is_blood_marked(t))
    except Exception:
        pass
    events.append(
        {
            "kind": kind,
            "who": name,
            "sin": sin,
            "marked": marked,
            "location": location or getattr(character, "location", "") or "",
            "detail": (detail or "")[:80],
            "ts": t,
        }
    )
    state["player_events"] = events[-20:]
    _save(state)

    should = force_run
    trigger = kind
    if not should:
        if kind in ("blood_mark", "sin_spike") or marked or sin >= 120:
            should = True
            trigger = "blood_mark" if marked or sin >= 120 else kind
        elif kind == "kill" and sin >= 80:
            should = True
            trigger = "kill_sin"
        elif kind == "manual":
            should = True
            trigger = "manual"
    if not should:
        return {"ok": False, "skipped": "event_below_threshold", "kind": kind}

    return WorldDirector.run_cycle(trigger=trigger, force=force_run or marked or sin >= 120, now=t)


def apply_directive(d: Dict[str, Any], *, now: Optional[float] = None) -> Dict[str, Any]:
    """规则侧落账：频道 / 目标 / 秘境开启 / 态势标记（态势由 world_modifiers 消费）"""
    t = _now(now)
    applied: Dict[str, Any] = {"channel": False, "goals": 0, "realm": "", "flags": []}
    dtype = d.get("type")
    effects = d.get("effects") or {}
    title = d.get("title") or "天道有感"
    narrative = d.get("narrative") or ""
    loc = d.get("location") or ""
    level = d.get("channel_level") or "major"
    text = f"【天道导演】{title}：{narrative}"
    if loc:
        text = f"{text} @{loc}"

    # 秘境提前开启
    if dtype == "secret_realm_pressure" and effects.get("force_open"):
        rid = str(effects.get("realm_id") or "")
        try:
            from core.secret_realm import director_force_open

            ok = director_force_open(rid, now=t)
            applied["realm"] = rid if ok else ""
            applied["flags"].append("realm_opened" if ok else "realm_open_failed")
            if ok:
                applied["flags"].append(rid)
        except Exception as e:
            applied["flags"].append(f"realm_err:{type(e).__name__}")

    # 血煞/宗门态势（活跃指令即世界修饰源）
    if dtype == "blood_tide":
        applied["flags"].append("blood_tide")
        eloc = str(effects.get("location") or loc or "")
        if eloc:
            applied["flags"].append(f"loc:{eloc}")
        try:
            from storage.db import ChronicleRepository

            ChronicleRepository.record(
                "天道导演", "血煞", f"血煞潮起：{title}" + (f"@{eloc}" if eloc else "")
            )
        except Exception:
            pass
    if dtype == "sect_tension":
        sa = str(effects.get("sect_a") or "")
        sb = str(effects.get("sect_b") or "")
        applied["flags"].append(f"sect:{sa}vs{sb}")
        try:
            from storage.db import ChronicleRepository

            ChronicleRepository.record("天道导演", "宗门", f"{sa}×{sb} 关系紧张：{title}")
        except Exception:
            pass
        # 规则侧：双方法门下 NPC 态度微降（可感知宗门紧张，非胜负改数）
        try:
            from core.npc_mind import shift_attitude, _is_npc

            npcs_a = []
            npcs_b = []
            for c in CharacterRepository.list_all_alive():
                if not _is_npc(c) or c.status == CharacterStatus.DEAD:
                    continue
                if c.sect == sa:
                    npcs_a.append(c)
                elif c.sect == sb:
                    npcs_b.append(c)
            for a in npcs_a[:3]:
                for b in npcs_b[:3]:
                    shift_attitude(a, b.id, -8, reason=f"天道导演·宗门紧张{sa}×{sb}")
                    shift_attitude(b, a.id, -8, reason=f"天道导演·宗门紧张{sa}×{sb}")
            if npcs_a or npcs_b:
                applied["flags"].append(f"attitude_pairs:{min(3,len(npcs_a))}x{min(3,len(npcs_b))}")
        except Exception as e:
            applied["flags"].append(f"attitude_err:{type(e).__name__}")
    if dtype == "calamity_forecast":
        applied["flags"].append("calamity_forecast")
        try:
            from core.goals import GoalEngine
            from core.season import season_info as _si

            info = _si(t)
            g_detail = (
                f"纪元第 {info.get('season_number')} 天，余约 {info.get('remain_real_days')} 天。"
                f"{narrative[:80]}"
            )
            n_goal = 0
            for c in CharacterRepository.list_all_alive():
                uid = str(getattr(c, "user_id", "") or "")
                if uid.startswith("npc_") or uid.startswith("ai_npc_"):
                    continue
                if c.status == CharacterStatus.DEAD:
                    continue
                if GoalEngine.add_opportunity(c, f"大劫预兆·{title}", g_detail).get("success"):
                    n_goal += 1
                    try:
                        CharacterRepository.save(c)
                    except Exception:
                        pass
                if n_goal >= DIRECTOR_GOAL_FANOUT:
                    break
            applied["goals"] = int(applied.get("goals") or 0) + n_goal
        except Exception:
            pass
    if dtype == "faction_order":
        try:
            from core import faction as faction_mod

            res = faction_mod.director_apply_faction_order(d, now=t)
            applied["flags"].append("faction_order_ok" if res.get("ok") else f"faction_order_fail:{res.get('error')}")
            if res.get("mission"):
                applied["flags"].append(f"mission:{res['mission'].get('id')}")
        except Exception as e:
            applied["flags"].append(f"faction_err:{type(e).__name__}")
    if dtype == "sect_siege":
        try:
            from core import faction as faction_mod

            res = faction_mod.director_apply_sect_siege(d, now=t)
            applied["flags"].append("siege_ok" if res.get("ok") else f"siege_fail:{res.get('error')}")
        except Exception as e:
            applied["flags"].append(f"siege_err:{type(e).__name__}")
    # 宗门紧张时同步势力系统
    if dtype == "sect_tension":
        try:
            from core import faction as faction_mod

            faction_mod.on_director_sect_tension(
                str(effects.get("sect_a") or ""),
                str(effects.get("sect_b") or ""),
                now=t,
            )
            applied["flags"].append("faction_tension_synced")
        except Exception:
            pass

    # 机缘目标投射
    if dtype in ("omen", "secret_realm_pressure") and (
        effects.get("goal_title") or dtype == "omen" or dtype == "secret_realm_pressure"
    ):
        g_title = str(effects.get("goal_title") or title)[:40]
        g_detail = str(effects.get("goal_detail") or narrative)[:200]
        if dtype == "secret_realm_pressure":
            rid = str(effects.get("realm_id") or "")
            g_title = str(effects.get("goal_title") or f"秘境风声·{rid or title}")[:40]
            g_detail = str(effects.get("goal_detail") or narrative)[:200]
        n = 0
        try:
            from core.goals import GoalEngine

            targets: List[Any] = []
            for c in CharacterRepository.list_all_alive():
                uid = str(getattr(c, "user_id", "") or "")
                if uid.startswith("npc_") or uid.startswith("ai_npc_"):
                    continue
                if c.status == CharacterStatus.DEAD:
                    continue
                targets.append(c)
                if len(targets) >= DIRECTOR_GOAL_FANOUT:
                    break
            for c in targets:
                res = GoalEngine.add_opportunity(c, g_title, g_detail)
                if res.get("success"):
                    n += 1
                    try:
                        CharacterRepository.save(c)
                    except Exception:
                        pass
            applied["goals"] = n
        except Exception as e:
            applied["flags"].append(f"goal_err:{type(e).__name__}")

    # 频道播报（directive 入库不依赖频道限流成功）
    try:
        msg = WorldChannel.post(
            "director",
            text[:160],
            level=level,
            actor=f"director:{dtype}",
            location=loc,
            now=t,
            skip_limit=True,
        )
        applied["channel"] = msg is not None
    except Exception:
        applied["channel"] = False

    _audit(
        {
            "event": "apply",
            "directive_id": d.get("id"),
            "type": dtype,
            "source": d.get("source"),
            "applied": applied,
        }
    )
    return applied


class WorldDirector:
    """世界走向导演：周期/事件触发，AI 提案 + 规则落账"""

    @staticmethod
    def tick_gate_ok(now: Optional[float] = None) -> bool:
        t = _now(now)
        state = _load()
        last = float(state.get("last_run_ts") or 0)
        return (t - last) >= float(DIRECTOR_TICK_INTERVAL_SECONDS)

    @staticmethod
    def run_cycle(
        trigger: str = "timer",
        *,
        force: bool = False,
        now: Optional[float] = None,
        gateway: Any = None,
    ) -> Dict[str, Any]:
        t = _now(now)
        state = _load()
        _prune_active(state, t)

        last = float(state.get("last_run_ts") or 0)
        # 大劫窗口：若尚无 calamity_forecast 活跃指令，放宽 tick 闸（仍尊重最小冷却除非 force）
        try:
            info_now = season_info(t)
            in_calamity_window = bool(info_now.get("is_final_week")) or float(
                info_now.get("remain_real_days") or 0
            ) <= float(SEASON_WARN_DAYS)
        except Exception:
            in_calamity_window = False
        has_calamity_dir = any(
            isinstance(d, dict) and d.get("type") == "calamity_forecast"
            for d in (state.get("active") or [])
        )
        calamity_need = in_calamity_window and not has_calamity_dir

        if not force and (t - last) < float(DIRECTOR_MIN_INTERVAL_SECONDS):
            # 大劫急需且无预兆：允许突破最小冷却
            if not calamity_need:
                state["stats"]["attempts"] = int(state["stats"].get("attempts") or 0) + 1
                state["last_trigger"] = trigger
                state["last_source"] = "skipped"
                state["last_error"] = "cooldown"
                _save(state)
                return {
                    "ok": False,
                    "skipped": "cooldown",
                    "message": f"天道未至再演之时（冷却 {DIRECTOR_MIN_INTERVAL_SECONDS:.0f}s）",
                }

        if not force and trigger == "timer":
            # tick 路径额外墙钟闸；大劫窗口待发预兆时放行
            if (t - last) < float(DIRECTOR_TICK_INTERVAL_SECONDS) and not calamity_need:
                state["stats"]["attempts"] = int(state["stats"].get("attempts") or 0) + 1
                state["last_trigger"] = trigger
                state["last_source"] = "skipped"
                state["last_error"] = "tick_gate"
                _save(state)
                return {"ok": False, "skipped": "tick_gate", "message": "导演 tick 闸未开"}

        if len(state.get("active") or []) >= DIRECTOR_MAX_ACTIVE and not force:
            # 大劫预兆优先：满员时可替换最旧的一条非 calamity
            if not (calamity_need and in_calamity_window):
                state["stats"]["attempts"] = int(state["stats"].get("attempts") or 0) + 1
                state["last_trigger"] = trigger
                state["last_source"] = "skipped"
                state["last_error"] = "max_active"
                _save(state)
                return {"ok": False, "skipped": "max_active", "message": "世间已有足够天道态势"}

        # 进入实际提案阶段才计 runs
        state["stats"]["runs"] = int(state.get("stats", {}).get("runs") or 0) + 1
        state["stats"]["attempts"] = int(state["stats"].get("attempts") or 0) + 1

        brief = gather_world_brief(t)
        if gateway is not None:
            # 测试注入
            try:
                raw = gateway(director_prompt_for_test(brief, force=force))
                data = raw if isinstance(raw, dict) else {}
                raw_list = data.get("directives") or []
                cleaned: List[Dict[str, Any]] = []
                rejected = 0
                for item_raw in raw_list[:DIRECTOR_MAX_ACTIVE]:
                    ok, reason, item = admit_directive(
                        item_raw, season=brief.get("season"), now=t
                    )
                    if ok and item:
                        item["source"] = "ai"
                        cleaned.append(item)
                    else:
                        rejected += 1
                        _audit({"event": "reject", "reason": reason, "source": "ai"})
                state["stats"]["rejected"] = int(state["stats"].get("rejected") or 0) + rejected
                source, error = "ai", (f"rejected={rejected}" if rejected else "")
            except Exception as e:
                cleaned, source, error = [], "error", f"{type(e).__name__}: {e}"[:200]
                if local_ai_allowed():
                    cleaned, source = _local_directives(brief, t), "local"
        else:
            cleaned, source, error = _ai_propose(brief, force=force, now=t)

        # 统一：批内去重 + 对活跃指令去重
        if cleaned:
            cleaned = _dedupe_cleaned(cleaned)
            deduped = []
            for item in cleaned:
                if _is_duplicate_directive(item, now=t):
                    continue
                deduped.append(item)
            cleaned = deduped[:DIRECTOR_MAX_ACTIVE]

        if source == "error" and not cleaned:
            state.update(
                {
                    "last_run_ts": t,
                    "last_trigger": trigger,
                    "last_source": "error",
                    "last_error": error or "director_unavailable",
                    "last_accepted": 0,
                }
            )
            _save(state)
            _audit({"event": "run_error", "trigger": trigger, "error": error})
            return {
                "ok": False,
                "error": error or "director_unavailable",
                "message": error or ai_block_reason() or "天道导演暂不可用",
                "source": "error",
            }

        applied_rows = []
        for d in cleaned:
            d.setdefault("source", source)
            d["applied"] = apply_directive(d, now=t)
            applied_rows.append(d)

        state["active"] = (state.get("active") or []) + applied_rows
        _prune_active(state, t)
        if len(state["active"]) > DIRECTOR_MAX_ACTIVE:
            # 大劫预兆优先保留
            cal = [d for d in state["active"] if d.get("type") == "calamity_forecast"]
            others = [d for d in state["active"] if d.get("type") != "calamity_forecast"]
            state["active"] = (others + cal)[-DIRECTOR_MAX_ACTIVE:]
        state["last_run_ts"] = t
        state["last_trigger"] = trigger
        state["last_source"] = source
        state["last_error"] = error or ""
        state["last_accepted"] = len(applied_rows)
        state["stats"]["accepted"] = int(state["stats"].get("accepted") or 0) + len(applied_rows)
        for d in applied_rows:
            _push_history(
                state,
                f"{int(t)}|{d.get('type')}|{d.get('title')}|{d.get('source')}|{d.get('id')}",
            )
        _save(state)
        # M2：导师指令升格世界弧
        arcs_spawned = []
        try:
            from core.world_arc import absorb_director_cycle

            arcs_spawned = absorb_director_cycle(applied_rows, now=t)
        except Exception:
            arcs_spawned = []
        return {
            "ok": True,
            "source": source,
            "trigger": trigger,
            "count": len(applied_rows),
            "directives": applied_rows,
            "arcs_spawned": arcs_spawned,
            "brief_hint": (applied_rows[0].get("title") if applied_rows else "天道沉寂"),
        }

    @staticmethod
    def format_heaven_board(now: Optional[float] = None) -> str:
        t = _now(now)
        state = _load()
        _prune_active(state, t)
        src = state.get("last_source") or "—"
        src_cn = {
            "ai": "服务器 AI",
            "local": "本地降级（非正式）",
            "error": "不可用",
            "skipped": "未触发",
            "": "尚未运行",
        }.get(src, src)
        lines = ["【天道导演】AI 提案 · 规则落账（主导走向，不直接改数值）"]
        lines.append(
            f"上次运行：{_fmt_ts(state.get('last_run_ts'))} · 触发 {state.get('last_trigger') or '—'} "
            f"· 来源 {src_cn}"
        )
        if state.get("last_error"):
            lines.append(f"备注：{state.get('last_error')}")
        stats = state.get("stats") or {}
        lines.append(
            f"累计：提案 {stats.get('runs', 0)} · 尝试 {stats.get('attempts', stats.get('runs', 0))} "
            f"· 落账 {stats.get('accepted', 0)} · 驳回 {stats.get('rejected', 0)}"
        )
        active = state.get("active") or []
        lines.append(f"活跃指令（{len(active)}）：")
        if not active:
            lines.append("  · 世间暂无导演态势（可用 /天道 推演 触发）")
        for i, d in enumerate(active[:8], 1):
            loc = f" @{d.get('location')}" if d.get("location") else ""
            src_d = d.get("source") or ""
            mark = "〔local〕" if src_d == "local" else ""
            lines.append(
                f"  {i}. [{d.get('type')}] {mark}{d.get('title')}{loc} · 剩余约 "
                f"{max(0, int(float(d.get('expires_at') or 0) - t))}s"
            )
            if d.get("narrative"):
                lines.append(f"     {d.get('narrative')}")
            ap = d.get("applied") or {}
            bits = []
            if ap.get("channel"):
                bits.append("已播报")
            if ap.get("goals"):
                bits.append(f"机缘目标×{ap.get('goals')}")
            if ap.get("realm"):
                bits.append(f"秘境:{ap.get('realm')}")
            if bits:
                lines.append(f"     落账：{' · '.join(bits)}")
        hist = list(state.get("history") or [])[-5:]
        if hist:
            lines.append("近史：")
            for h in reversed(hist):
                parts = str(h).split("|")
                if len(parts) >= 4:
                    lines.append(f"  · {parts[2]}（{parts[1]} · {parts[3]}）")
        try:
            mods = world_modifiers(t)
            fac = mods.get("faction") or {}
            lines.append(
                "世界修饰："
                f"血煞潮地={mods.get('blood_tide_locations') or '无'} · "
                f"宗门紧张={mods.get('sect_tensions') or '无'} · "
                f"大劫预兆={'是' if mods.get('calamity_forecast') else '否'} · "
                f"除凶热度×{mods.get('hunt_heat', 1.0):.2f}"
            )
            if fac.get("active_sieges") or fac.get("hostile_pairs"):
                lines.append(
                    f"势力：围剿={fac.get('active_sieges') or '无'} · "
                    f"敌对对={len(fac.get('hostile_pairs') or [])}"
                )
            em = mods.get("echo") or {}
            if em.get("market_panic") or em.get("hot_regions"):
                lines.append(
                    f"望气：血气{em.get('blood_index', 0):.0f} · 恐慌{em.get('market_panic', 0):.0f} · "
                    f"凶地={em.get('hot_regions') or '无'}"
                )
        except Exception:
            pass
        try:
            from core.era_reentry import format_era_board

            # 精简一行
            from core.era_reentry import active_bias, TYPE_CN

            bias = active_bias(t)
            if bias:
                top = sorted(bias.items(), key=lambda x: -x[1])[:3]
                lines.append(
                    "纪元回流："
                    + "、".join(f"{TYPE_CN.get(k, k)}{v:.0f}" for k, v in top)
                    + "（/纪元回流 详情）"
                )
        except Exception:
            pass
        try:
            from core.world_arc import active_arcs, format_arc_board

            arcs = active_arcs(t)
            if arcs:
                lines.append(f"世界弧（{len(arcs)}）：")
                for a in arcs[:4]:
                    stage_cn = {"prophesy": "预兆", "escalate": "升级", "climax": "决算"}.get(
                        a.get("stage"), a.get("stage")
                    )
                    loc = f" @{a.get('location')}" if a.get("location") else ""
                    lines.append(f"  · [{stage_cn}] {a.get('title')}{loc}（{a.get('kind')}）")
                lines.append("  详情：/世界弧")
            else:
                lines.append("世界弧：暂无进行中")
        except Exception:
            pass
        pe = list(state.get("player_events") or [])[-3:]
        if pe:
            lines.append("近惊动天道：")
            for e in reversed(pe):
                lines.append(
                    f"  · {e.get('kind')} · {e.get('who') or '—'}"
                    f"{(' @' + e['location']) if e.get('location') else ''}"
                    f" · 业力{e.get('sin', 0)}"
                )
        lines.append("权限边界：AI 只提案态势/目标提示；胜负与掉落仍归规则引擎。")
        return "\n".join(lines)

    @staticmethod
    def schedule_lines(now: Optional[float] = None, limit: int = 3) -> List[str]:
        t = _now(now)
        state = _load()
        _prune_active(state, t)
        rows = []
        for d in (state.get("active") or [])[:limit]:
            loc = f" @{d.get('location')}" if d.get("location") else ""
            rows.append(f"· [{d.get('type')}] {d.get('title')}{loc}")
        return rows


def _fmt_ts(ts: Any) -> str:
    try:
        ts = float(ts or 0)
        if ts <= 0:
            return "从未"
        return time.strftime("%m-%d %H:%M:%S", time.localtime(ts))
    except Exception:
        return "—"


# 供测试注入的 prompt 桥（避免 circular 在 run_cycle 内延迟 import 失败）
def director_prompt_for_test(brief: Dict[str, Any], force: bool = False) -> str:
    from ai.play_prompts import director_prompt

    info = brief.get("season") or {}
    return director_prompt(
        brief.get("text", ""),
        season_remain_days=float(info.get("remain_real_days") or 0),
        force=force,
    )


def director_snapshot(now: Optional[float] = None) -> Dict[str, Any]:
    """网页/HUD 结构化快照：导师 + 弧 + 势力 + 望气 + 纪元回流"""
    t = _now(now)
    state = _load()
    _prune_active(state, t)
    snap: Dict[str, Any] = {
        "ok": True,
        "server_time": t,
        "director": {
            "last_run_ts": state.get("last_run_ts"),
            "last_trigger": state.get("last_trigger") or "",
            "last_source": state.get("last_source") or "",
            "last_error": state.get("last_error") or "",
            "last_accepted": state.get("last_accepted") or 0,
            "stats": state.get("stats") or {},
            "active": [
                {
                    "id": d.get("id"),
                    "type": d.get("type"),
                    "title": d.get("title"),
                    "narrative": d.get("narrative"),
                    "location": d.get("location"),
                    "source": d.get("source"),
                    "expires_at": d.get("expires_at"),
                    "applied": d.get("applied") or {},
                }
                for d in (state.get("active") or [])[:8]
            ],
            "history": list(state.get("history") or [])[-8:],
            "board_text": "",
        },
        "modifiers": {},
        "arcs": [],
        "faction": {},
        "echo": {},
        "era": {},
        "quality": {},
    }
    try:
        snap["director"]["board_text"] = WorldDirector.format_heaven_board(t)
        snap["modifiers"] = world_modifiers(t)
    except Exception as e:
        snap["director"]["board_text"] = f"导演面板暂不可用：{e}"
    try:
        from core.world_arc import active_arcs, format_arc_board

        snap["arcs"] = [
            {
                "id": a.get("id"),
                "kind": a.get("kind"),
                "title": a.get("title"),
                "stage": a.get("stage"),
                "location": a.get("location"),
                "stage_deadline": a.get("stage_deadline"),
            }
            for a in active_arcs(t)[:8]
        ]
        snap["arc_board_text"] = format_arc_board(t)
    except Exception:
        snap["arc_board_text"] = ""
    try:
        from core.faction import faction_modifiers, format_faction_board, get_relation
        from config import SECTS_CONFIG as _SC

        fm = faction_modifiers(t)
        relations = []
        names = list(_SC.keys())
        for i, a in enumerate(names):
            for b in names[i + 1 :]:
                r = get_relation(a, b, t)
                relations.append(
                    {
                        "a": r.get("a") or a,
                        "b": r.get("b") or b,
                        "score": r.get("score"),
                        "status": r.get("status"),
                        "note": r.get("note"),
                    }
                )
        snap["faction"] = {
            "modifiers": fm,
            "relations": relations,
            "board_text": format_faction_board(now=t),
        }
    except Exception:
        snap["faction"] = {"modifiers": {}, "relations": [], "board_text": ""}
    try:
        from core.player_echo import echo_modifiers, format_echo_board

        snap["echo"] = {
            "modifiers": echo_modifiers(t),
            "board_text": format_echo_board(t),
        }
    except Exception:
        snap["echo"] = {"modifiers": {}, "board_text": ""}
    try:
        from core.era_reentry import active_bias, format_era_board, TYPE_CN

        bias = active_bias(t)
        snap["era"] = {
            "bias": bias,
            "bias_cn": {TYPE_CN.get(k, k): v for k, v in bias.items()},
            "board_text": format_era_board(t),
        }
    except Exception:
        snap["era"] = {"bias": {}, "bias_cn": {}, "board_text": ""}
    try:
        snap["quality"] = director_quality_report(t)
    except Exception:
        snap["quality"] = {}
    return snap


def director_quality_report(now: Optional[float] = None) -> Dict[str, Any]:
    """导师链路质量自检（不打真实 LLM，只查本地状态与模块）"""
    t = _now(now)
    state = _load()
    _prune_active(state, t)
    checks: List[Dict[str, Any]] = []

    def _ck(name: str, ok: bool, detail: str = "") -> None:
        checks.append({"name": name, "ok": bool(ok), "detail": detail[:120]})

    from config import ai_available, local_ai_allowed

    _ck("ai_channel_configured", ai_available() or local_ai_allowed(),
        "有 Key/CCSWITCH" if ai_available() else ("仅本地降级" if local_ai_allowed() else "未配置且禁止降级"))
    try:
        from ai.gateway import ai_health_status as _hs

        health = _hs() or {}
        err = str(health.get("error") or "")
        _ck("ai_health_probe", bool(health.get("ok")) or not err,
            err[:80] if err else str(health.get("ok") or "未探测/缓存无错")[:80])
    except Exception as e:
        _ck("ai_health_probe", False, type(e).__name__)
    _ck("director_types", "omen" in DIRECTOR_TYPES, f"types={sorted(DIRECTOR_TYPES)}")
    _ck("active_directives", True, f"n={len(state.get('active') or [])}")
    stats = state.get("stats") or {}
    _ck("director_runs", int(stats.get("runs") or 0) >= 0,
        f"runs={stats.get('runs',0)} accepted={stats.get('accepted',0)} rejected={stats.get('rejected',0)}")
    try:
        from core.world_arc import active_arcs

        _ck("world_arc", True, f"active={len(active_arcs(t))}")
    except Exception as e:
        _ck("world_arc", False, type(e).__name__)
    try:
        from core.faction import faction_modifiers

        fm = faction_modifiers(t)
        _ck("faction", True, f"sieges={len(fm.get('active_sieges') or [])} hostile={len(fm.get('hostile_pairs') or [])}")
    except Exception as e:
        _ck("faction", False, type(e).__name__)
    try:
        from core.player_echo import echo_modifiers

        em = echo_modifiers(t)
        _ck("player_echo", True, f"panic={em.get('market_panic')} hot={len(em.get('hot_regions') or [])}")
    except Exception as e:
        _ck("player_echo", False, type(e).__name__)
    try:
        from core.era_reentry import active_bias

        bias = active_bias(t)
        _ck("era_reentry", True, f"bias_keys={list(bias.keys())[:4]}")
    except Exception as e:
        _ck("era_reentry", False, type(e).__name__)
    # 门禁自证：非法 type 应被拒
    ok_gate, reason_gate, _ = admit_directive({"type": "nuke", "title": "x", "narrative": "y"}, now=t)
    _ck("gate_rejects_illegal", ok_gate is False, reason_gate)
    ok_strip, _, item_strip = admit_directive(
        {"type": "omen", "title": "t", "narrative": "n", "effects": {"exp": 9999}},
        now=t,
    )
    _ck("gate_strips_numeric", ok_strip and item_strip is not None and "exp" not in (item_strip.get("effects") or {}), "")
    passed = sum(1 for c in checks if c["ok"])
    return {
        "passed": passed,
        "total": len(checks),
        "checks": checks,
        "ready_for_ai_director": ai_available(),
        "local_fallback_allowed": local_ai_allowed(),
        "prompt_scene": "world_director",
        "quota_hint": "见 ai/quota SCENE_LIMITS.world_director",
    }


def handle_heaven_command(action: str, parts: List[str]) -> Dict[str, Any]:
    """/天道 面板与推演"""
    sub = (parts[1].strip() if len(parts) > 1 else "").lower()
    if sub in ("推演", "run", "演", "tick"):
        res = WorldDirector.run_cycle(trigger="command", force=True)
        board = WorldDirector.format_heaven_board()
        if res.get("ok"):
            return {
                "ok": True,
                "text": f"天道导演已推演：{res.get('brief_hint', '')}\n\n{board}",
                "director": res,
            }
        return {
            "ok": False,
            "text": f"天道导演未能推演：{res.get('message') or res.get('error')}\n\n{board}",
            "director": res,
        }
    return {"ok": True, "text": WorldDirector.format_heaven_board()}
